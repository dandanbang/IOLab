import sqlite3 as sql

def insert_customer():
    # SQL statement to insert into database goes here

def retrieve_customers():
    # SQL statement to query database goes here
