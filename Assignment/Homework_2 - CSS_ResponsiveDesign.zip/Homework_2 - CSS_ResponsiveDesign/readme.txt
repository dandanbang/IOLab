This is assignment folder.
